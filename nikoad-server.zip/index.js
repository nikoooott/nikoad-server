const express = require('express');
const bodyParser = require('body-parser');
const fetch = require('node-fetch');

const app = express();
app.use(bodyParser.json());

const TOKEN = '8010834456:AAHIsuzexb2FoGNPsNjF-_BXe6r_KovMLn0';
const CHAT_ID = '1615873144';

app.post('/api/send', async (req, res) => {
  const { name, tg, msg } = req.body;

  if (!name || !tg || !msg) {
    return res.status(400).send('Missing fields');
  }

  const text = `Новая заявка:\nИмя: ${name}\nTelegram: ${tg}\nКомментарий: ${msg}`;

  try {
    await fetch(`https://api.telegram.org/bot${TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: CHAT_ID, text })
    });

    res.status(200).send('OK');
  } catch (err) {
    console.error(err);
    res.status(500).send('Error sending message');
  }
});

app.get('/', (req, res) => res.send('Server is running!'));

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on ${PORT}`));
